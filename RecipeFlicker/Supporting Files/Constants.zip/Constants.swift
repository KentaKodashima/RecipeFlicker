//
//  Constants.swift
//  RecipeFlicker
//
//  Created by Kenta Kodashima on 2018-11-08.
//  Copyright © 2018 Kenta Kodashima. All rights reserved.
//

import Foundation

let EDAMAM_APP_ID = "&app_id=64e158b2"
let EDAMAM_APP_KEY = "&app_key=7826daf17b47075ec9f3c74964f2ed8d"
